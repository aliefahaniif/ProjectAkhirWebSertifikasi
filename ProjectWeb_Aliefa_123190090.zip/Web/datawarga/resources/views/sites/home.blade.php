@extends('layouts.frontend')
@section('content')

@stop