@extends('layouts.master')

@section('content')
    <br><br><br>
    <h2>Ubah Data Warga</h2> 
    @if(session('sukses'))
    <div class="alert alert-success d-flex align-items-center" role="alert">
        {{session('sukses')}}
    </div>
    @endif
    
    <div class="row">
        <div class="col-6">
        <form action="/warga/{{$warga->id}}/update " method="POST">
                {{csrf_field()}}
                <div class="form-group">
                    <label for="nm" class="form-label">Nama</label>
                    <input name="nama" type="text" class="form-control" id="nm" aria-describedby="emailnama" placeholder="Nama" value="{{$warga->nama}}">
                </div>
                <div class="form-group">
                    <label for="jnsk">Jenis Kelamin</label>
                    <select name="jeniskelamin" class="form-control" id="jnsk">
                        <option value="Perempuan" @if($warga->jeniskelamin == "Perempuan") selected @endif>Perempuan</option>
                        <option value="Laki-laki" @if($warga->jeniskelamin == "Laki-laki") selected @endif>Laki-laki</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="almt" class="form-label">Asal</label>
                    <textarea name="alamat" type="text" class="form-control" id="almt" aria-describedby="Helpalamat" placeholder="Alamat">{{$warga->alamat}}</textarea>
                </div>
                <div class="form-group">
                    <label for="sts">Status</label>
                    <select name="status" class="form-control" id="sts">
                        <option value="Lajang" @if($warga->status == "Lajang") selected @endif >Lajang</option>
                        <option value="Menikah"@if($warga->status == "Menikah") selected @endif >Menikah</option>
                        <option value="Cerai" @if($warga->status == "Cerai") selected @endif >Cerai</option>
                    </select>
                </div>
                <br></br>
                <button type="submit" class="btn btn-primary">Edit</button>
                <a class="btn btn-secondary" href="/warga" role="button">Batal</a>
                </form>
                </div>
        </div>
        @endsection