


<?php $__env->startSection('content'); ?>

<br><br>
    <?php if(session('sukses')): ?>
    <div class="alert alert-success d-flex align-items-center" role="alert">
        <?php echo e(session('sukses')); ?>

    </div>
    <?php endif; ?>
    
    <div class="row">
    <h6>  </h6>
    <br><br><br>
    <h1>Data Warga Pendatang Baru</h1>
    <h6>Di bawah ini merupakan data warga pendatang yang berasal dari banyak daerah baik dalam negeri maupun luar negeri, informasi di bawah ini terdiri dari nama, jenis kelamin, asal dan status.</h6>
        <div class="col-6">
        <h4>Data</h4>
            <br>
            </div>
            <div class="col-6">
            <!-- Button trigger modal -->
            <button type="button" class="btn btn-outline-info float-end btn-lg" data-bs-toggle="modal" data-bs-target="#exampleModal">
            Insert Data 
            </button>
            <br>

            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                <form action="/warga/create" method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="nm" class="form-label">Nama</label>
                    <input name="nama" type="text" class="form-control" id="nm" aria-describedby="emailnama" placeholder="Nama">
                </div>
                <div class="form-group">
                    <label for="jnsk">Jenis Kelamin</label>
                    <select name="jeniskelamin" class="form-control" id="jnsk">
                        <option value="Perempuan">Perempuan</option>
                        <option value="Laki-laki">Laki-laki</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="almt" class="form-label">Asal</label>
                    <textarea name="alamat" type="text" class="form-control" id="almt" aria-describedby="Helpalamat" placeholder="Alamat"></textarea>
                </div>
                <div class="form-group">
                    <label for="sts">Status</label>
                    <select name="status" class="form-control" id="sts">
                        <option value="Lajang">Lajang</option>
                        <option value="Menikah">Menikah</option>
                        <option value="Cerai">Cerai</option>
                    </select>
                </div>
                <br></br>
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </form>
                </div>            
                </div>
            </div>
            </div>
            </div>
        <table class="table table-striped table-secondary table-hover">
        <tr>
            <th>Nama</th>
            <th>Jenis Kelamin</th>
            <th>Alamat</th>
            <th>Status</th>
            <th>Aksi</th> 
        </tr>
        <?php $__currentLoopData = $data_warga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($warga->nama); ?></td>
            <td><?php echo e($warga->jeniskelamin); ?></td>
            <td><?php echo e($warga->alamat); ?></td>
            <td><?php echo e($warga->status); ?></td>
            <td>
                <a href="/warga/<?php echo e($warga->id); ?>/edit" class="btn btn-outline-primary btn-sm">Edit</a>
                <a href="/warga/<?php echo e($warga->id); ?>/delete" class="btn btn-outline-danger btn-sm" onclick="return confirm('Apakah anda yakin data ini ingin dihapus?')">Hapus</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KULIAH\Web\datawarga\resources\views/warga/index.blade.php ENDPATH**/ ?>