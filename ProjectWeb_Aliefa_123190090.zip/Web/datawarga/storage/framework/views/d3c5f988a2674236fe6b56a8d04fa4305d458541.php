

<?php $__env->startSection('content'); ?>
    <br><br><br>
    <h2>Ubah Data Warga</h2> 
    <?php if(session('sukses')): ?>
    <div class="alert alert-success d-flex align-items-center" role="alert">
        <?php echo e(session('sukses')); ?>

    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-6">
        <form action="/warga/<?php echo e($warga->id); ?>/update " method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label for="nm" class="form-label">Nama</label>
                    <input name="nama" type="text" class="form-control" id="nm" aria-describedby="emailnama" placeholder="Nama" value="<?php echo e($warga->nama); ?>">
                </div>
                <div class="form-group">
                    <label for="jnsk">Jenis Kelamin</label>
                    <select name="jeniskelamin" class="form-control" id="jnsk">
                        <option value="Perempuan" <?php if($warga->jeniskelamin == "Perempuan"): ?> selected <?php endif; ?>>Perempuan</option>
                        <option value="Laki-laki" <?php if($warga->jeniskelamin == "Laki-laki"): ?> selected <?php endif; ?>>Laki-laki</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="almt" class="form-label">Asal</label>
                    <textarea name="alamat" type="text" class="form-control" id="almt" aria-describedby="Helpalamat" placeholder="Alamat"><?php echo e($warga->alamat); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="sts">Status</label>
                    <select name="status" class="form-control" id="sts">
                        <option value="Lajang" <?php if($warga->status == "Lajang"): ?> selected <?php endif; ?> >Lajang</option>
                        <option value="Menikah"<?php if($warga->status == "Menikah"): ?> selected <?php endif; ?> >Menikah</option>
                        <option value="Cerai" <?php if($warga->status == "Cerai"): ?> selected <?php endif; ?> >Cerai</option>
                    </select>
                </div>
                <br></br>
                <button type="submit" class="btn btn-primary">Edit</button>
                <a class="btn btn-secondary" href="/warga" role="button">Batal</a>
                </form>
                </div>
        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\KULIAH\Web\datawarga\resources\views/warga/edit.blade.php ENDPATH**/ ?>